import './style.scss';

const FieldRow = ({children}) => {
    return <div className="give-donor-dashboard-field-row">{children}</div>;
};
export default FieldRow;
