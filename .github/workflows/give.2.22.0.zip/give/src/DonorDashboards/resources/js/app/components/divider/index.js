import './style.scss';
const Divider = () => {
    return <div className="give-donor-dashboard-divider" />;
};
export default Divider;
