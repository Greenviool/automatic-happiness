export const initialState = {
    annualReceipts: null,
    querying: false,
    error: null,
};
