import DashboardContent from '../../components/dashboard-content';

const Content = () => {
    return <DashboardContent />;
};
export default Content;
